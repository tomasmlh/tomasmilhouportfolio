
// ----- Lightbox & Carousel -----
(function(){
  const galleryGrids = document.querySelectorAll('.gallery');
  const lightbox = document.getElementById('lightbox');
  if (!lightbox) return; // not on gallery page
  const carousel = lightbox.querySelector('.carousel');
  const slides = Array.from(lightbox.querySelectorAll('.slide'));
  const counter = document.getElementById('counter');
  const prevBtn = document.getElementById('prevBtn');
  const nextBtn = document.getElementById('nextBtn');
  const leftArrow = lightbox.querySelector('.arrow.left');
  const rightArrow = lightbox.querySelector('.arrow.right');

  let current = 0;
  let touchStartX = 0;
  let touchEndX = 0;

  function openLightbox(index){
    current = index;
    update();
    lightbox.classList.add('open');
    document.body.style.overflow = 'hidden';
  }
  function closeLightbox(){
    lightbox.classList.remove('open');
    document.body.style.overflow = '';
  }
  function update(){
    slides.forEach((s,i)=> s.classList.toggle('active', i===current));
    counter.textContent = (current+1);
    carousel.dataset.current = String(current);
  }
  function next(dir=1){
    current = (current + dir + slides.length) % slides.length;
    update();
  }

  // Click on grid -> open
  galleryGrids.forEach(grid=>{
    grid.addEventListener('click', (e)=>{
      const img = e.target.closest('img');
      if (!img) return;
      const figs = Array.from(grid.querySelectorAll('img'));
      openLightbox(figs.indexOf(img));
    });
  });

  // Controls
  nextBtn?.addEventListener('click', ()=> next(1));
  prevBtn?.addEventListener('click', ()=> next(-1));
  rightArrow?.addEventListener('click', ()=> next(1));
  leftArrow?.addEventListener('click', ()=> next(-1));

  // Keyboard
  window.addEventListener('keydown', (e)=>{
    if (!lightbox.classList.contains('open')) return;
    if (e.key === 'Escape') closeLightbox();
    if (e.key === 'ArrowRight') next(1);
    if (e.key === 'ArrowLeft') next(-1);
  });

  // Close on backdrop click
  lightbox.addEventListener('click', (e)=>{
    if (e.target === lightbox) closeLightbox();
  });

  // Touch (swipe)
  carousel.addEventListener('touchstart', (e)=>{ touchStartX = e.changedTouches[0].clientX; }, {passive:true});
  carousel.addEventListener('touchend', (e)=>{
    touchEndX = e.changedTouches[0].clientX;
    const dx = touchEndX - touchStartX;
    if (Math.abs(dx) > 40){
      next(dx < 0 ? 1 : -1);
    }
  }, {passive:true});
})();

// ----- Gmail compose from Contact form -----
function openGmail(e){
  e.preventDefault();
  const YOUR_EMAIL = "tuemail@gmail.com"; // TODO: cámbialo por tu email
  const name = document.getElementById('name').value.trim();
  const from = document.getElementById('from').value.trim();
  const subject = document.getElementById('subject').value.trim();
  const message = document.getElementById('message').value.trim();

  const bodyLines = [
    `Nombre: ${name}`,
    `Email: ${from}`,
    '',
    'Mensaje:',
    message
  ];
  const body = encodeURIComponent(bodyLines.join('\n'));
  const su = encodeURIComponent(subject);

  const url = `https://mail.google.com/mail/?view=cm&fs=1&to=${encodeURIComponent(YOUR_EMAIL)}&su=${su}&body=${body}`;
  window.open(url, '_blank');
  return false;
}
